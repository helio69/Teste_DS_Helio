####OBS#####

Na pasta bank: base utilizada para fazer as an�lises.
Na pasta g�ficos: est�o todos os gr�ficos plotados.

O arquivo teste-semantix.ipynb abre na IDE Jupyter.
O arquivo Modelo_Rapido_Orange.ows abre na ferramenta Orange.